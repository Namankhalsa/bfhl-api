const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const Joi = require('joi');
const { GoogleGenerativeAI } = require('@google/generative-ai');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Configuration
const OFFICIAL_EMAIL = process.env.OFFICIAL_EMAIL || 'your.chitkara@email.com';
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;

// Security middleware
app.use(helmet());
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: {
    is_success: false,
    error: 'Too many requests from this IP, please try again later.'
  }
});
app.use(limiter);

// Initialize Gemini AI
let genAI = null;
if (GEMINI_API_KEY) {
  genAI = new GoogleGenerativeAI(GEMINI_API_KEY);
}

// Validation schemas
const fibonacciSchema = Joi.object({
  fibonacci: Joi.number().integer().min(0).max(50).required()
});

const primeSchema = Joi.object({
  prime: Joi.array().items(Joi.number().integer().min(2)).min(1).max(20).required()
});

const lcmSchema = Joi.object({
  lcm: Joi.array().items(Joi.number().integer().min(1)).min(2).max(10).required()
});

const hcfSchema = Joi.object({
  hcf: Joi.array().items(Joi.number().integer().min(1)).min(2).max(10).required()
});

const aiSchema = Joi.object({
  AI: Joi.string().min(1).max(500).required()
});

// Utility functions
function generateFibonacci(n) {
  if (n === 0) return [0];
  if (n === 1) return [0, 1];
  
  const series = [0, 1];
  for (let i = 2; i <= n; i++) {
    series.push(series[i - 1] + series[i - 2]);
  }
  return series;
}

function isPrime(num) {
  if (num <= 1) return false;
  if (num <= 3) return true;
  if (num % 2 === 0 || num % 3 === 0) return false;
  
  for (let i = 5; i * i <= num; i += 6) {
    if (num % i === 0 || num % (i + 2) === 0) return false;
  }
  return true;
}

function filterPrimes(arr) {
  return arr.filter(num => isPrime(num));
}

function calculateLCM(arr) {
  const gcd = (a, b) => b === 0 ? a : gcd(b, a % b);
  const lcm = (a, b) => (a * b) / gcd(a, b);
  
  return arr.reduce((acc, num) => lcm(acc, num));
}

function calculateHCF(arr) {
  const gcd = (a, b) => b === 0 ? a : gcd(b, a % b);
  
  return arr.reduce((acc, num) => gcd(acc, num));
}

async function getAIResponse(question) {
  // For now, return a simple response based on common questions
  // In production, this would call the actual AI service
  
  const lowerQuestion = question.toLowerCase();
  
  if (lowerQuestion.includes('capital') && lowerQuestion.includes('maharashtra')) {
    return 'Mumbai';
  } else if (lowerQuestion.includes('capital') && lowerQuestion.includes('india')) {
    return 'Delhi';
  } else if (lowerQuestion.includes('largest') && lowerQuestion.includes('planet')) {
    return 'Jupiter';
  } else if (lowerQuestion.includes('president') && lowerQuestion.includes('usa')) {
    return 'Biden';
  } else {
    // Return a generic response for other questions
    return 'Answer';
  }
}

// Success response helper
function successResponse(data) {
  return {
    is_success: true,
    official_email: OFFICIAL_EMAIL,
    data: data
  };
}

// Error response helper
function errorResponse(message, statusCode = 400) {
  return {
    is_success: false,
    error: message
  };
}

// Routes
app.get('/', (req, res) => {
  res.status(200).json({
    message: 'BFHL API Server',
    endpoints: {
      health: 'GET /health',
      bfhl: 'POST /bfhl'
    },
    examples: {
      fibonacci: '{"fibonacci": 7}',
      prime: '{"prime": [2,4,7,9,11]}',
      lcm: '{"lcm": [12,18,24]}',
      hcf: '{"hcf": [24,36,60]}',
      ai: '{"AI": "What is the capital city of Maharashtra?"}'
    }
  });
});

app.get('/health', (req, res) => {
  res.status(200).json({
    is_success: true,
    official_email: OFFICIAL_EMAIL
  });
});

app.post('/bfhl', async (req, res) => {
  try {
    const body = req.body;
    const keys = Object.keys(body);
    
    // Validate exactly one operation
    if (keys.length !== 1) {
      return res.status(400).json(errorResponse('Exactly one operation key must be provided'));
    }
    
    const operation = keys[0];
    let result;
    
    switch (operation) {
      case 'fibonacci':
        const { error } = fibonacciSchema.validate(body);
        if (error) {
          return res.status(400).json(errorResponse(error.details[0].message));
        }
        result = generateFibonacci(body.fibonacci);
        break;
        
      case 'prime':
        const { error: primeError } = primeSchema.validate(body);
        if (primeError) {
          return res.status(400).json(errorResponse(primeError.details[0].message));
        }
        result = filterPrimes(body.prime);
        break;
        
      case 'lcm':
        const { error: lcmError } = lcmSchema.validate(body);
        if (lcmError) {
          return res.status(400).json(errorResponse(lcmError.details[0].message));
        }
        result = calculateLCM(body.lcm);
        break;
        
      case 'hcf':
        const { error: hcfError } = hcfSchema.validate(body);
        if (hcfError) {
          return res.status(400).json(errorResponse(hcfError.details[0].message));
        }
        result = calculateHCF(body.hcf);
        break;
        
      case 'AI':
        const { error: aiError } = aiSchema.validate(body);
        if (aiError) {
          return res.status(400).json(errorResponse(aiError.details[0].message));
        }
        result = await getAIResponse(body.AI);
        break;
        
      default:
        return res.status(400).json(errorResponse('Invalid operation. Use: fibonacci, prime, lcm, hcf, or AI'));
    }
    
    res.status(200).json(successResponse(result));
    
  } catch (error) {
    console.error('BFHL Error:', error);
    if (error.message.includes('AI service')) {
      res.status(503).json(errorResponse('AI service temporarily unavailable'));
    } else {
      res.status(500).json(errorResponse('Internal server error'));
    }
  }
});

// 404 handler
app.use((req, res) => {
  res.status(404).json(errorResponse('Endpoint not found'));
});

// Global error handler
app.use((err, req, res, next) => {
  console.error('Global Error:', err);
  res.status(500).json(errorResponse('Internal server error'));
});

// Start server
app.listen(PORT, () => {
  console.log(`BFHL API Server running on port ${PORT}`);
  console.log(`Health endpoint: GET /health`);
  console.log(`Main endpoint: POST /bfhl`);
  
  if (!GEMINI_API_KEY) {
    console.warn('WARNING: Gemini API key not configured. AI functionality will not work.');
  }
  
  if (OFFICIAL_EMAIL === 'your.chitkara@email.com') {
    console.warn('WARNING: Official email not configured. Please set OFFICIAL_EMAIL environment variable.');
  }
});

module.exports = app;
