# BFHL REST API

A robust REST API implementation for BFHL (Bajaj Finserv Health Limited) operations with AI integration.

## Features

- **POST /bfhl** - Process various operations (fibonacci, prime, lcm, hcf, AI)
- **GET /health** - Health check endpoint
- **AI Integration** - Uses Google Gemini API for intelligent responses
- **Security** - Rate limiting, input validation, helmet protection
- **Error Handling** - Comprehensive error responses with proper HTTP status codes
- **Production Ready** - Structured for deployment on Vercel, Railway, or Render

## Supported Operations

| Operation | Input | Output |
|-----------|-------|--------|
| `fibonacci` | Integer (0-50) | Fibonacci series array |
| `prime` | Integer array | Prime numbers array |
| `lcm` | Integer array | LCM value |
| `hcf` | Integer array | HCF value |
| `AI` | Question string | Single-word AI response |

## Setup Instructions

### Prerequisites
- Node.js 16.0.0 or higher
- npm or yarn

### Installation

1. Clone the repository
```bash
git clone <repository-url>
cd bfhl-api
```

2. Install dependencies
```bash
npm install
```

3. Set up environment variables
```bash
cp .env.example .env
```

4. Configure your environment
Edit `.env` file with:
- Your Chitkara University email
- Google Gemini API key (get from https://aistudio.google.com)

### Running Locally

Development mode:
```bash
npm run dev
```

Production mode:
```bash
npm start
```

The server will start on port 3000 (or configured PORT).

## API Endpoints

### POST /bfhl

Process various mathematical and AI operations.

**Request Examples:**

```json
// Fibonacci
{
  "fibonacci": 7
}

// Prime numbers
{
  "prime": [2,4,7,9,11]
}

// LCM
{
  "lcm": [12,18,24]
}

// HCF
{
  "hcf": [24,36,60]
}

// AI Query
{
  "AI": "What is the capital city of Maharashtra?"
}
```

**Response Format:**
```json
{
  "is_success": true,
  "official_email": "your.email@chitkara.edu.in",
  "data": <result>
}
```

**Error Response:**
```json
{
  "is_success": false,
  "error": "Error message"
}
```

### GET /health

Health check endpoint.

**Response:**
```json
{
  "is_success": true,
  "official_email": "your.email@chitkara.edu.in"
}
```

## Deployment

### Vercel
1. Push code to GitHub repository
2. Connect Vercel account to GitHub
3. Import repository
4. Configure environment variables in Vercel dashboard
5. Deploy

### Railway
1. Create new project from GitHub
2. Select repository
3. Configure environment variables
4. Deploy

### Render
1. New Web Service → Connect GitHub
2. Select repository
3. Set build command: `npm install`
4. Set start command: `npm start`
5. Configure environment variables
6. Deploy

## Testing

Use curl or any API client to test endpoints:

```bash
# Health check
curl http://localhost:3000/health

# Fibonacci
curl -X POST http://localhost:3000/bfhl \
  -H "Content-Type: application/json" \
  -d '{"fibonacci": 7}'

# Prime numbers
curl -X POST http://localhost:3000/bfhl \
  -H "Content-Type: application/json" \
  -d '{"prime": [2,4,7,9,11]}'
```

## Security Features

- **Rate Limiting**: 100 requests per 15 minutes per IP
- **Input Validation**: Joi schema validation for all inputs
- **Helmet**: Security headers protection
- **CORS**: Cross-origin resource sharing configuration
- **Error Handling**: Graceful error responses without crashes

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `OFFICIAL_EMAIL` | Yes | Your Chitkara University email |
| `GEMINI_API_KEY` | Yes | Google Gemini API key |
| `PORT` | No | Server port (default: 3000) |

## Dependencies

- **express**: Web framework
- **cors**: CORS middleware
- **helmet**: Security headers
- **express-rate-limit**: Rate limiting
- **joi**: Input validation
- **@google/generative-ai**: Google Gemini AI
- **dotenv**: Environment variables

## License

MIT License

## Author

Chitkara University Student
