const http = require('http');

// Test data
const tests = [
  { operation: 'fibonacci', data: { fibonacci: 7 } },
  { operation: 'prime', data: { prime: [2, 4, 7, 9, 11] } },
  { operation: 'lcm', data: { lcm: [12, 18, 24] } },
  { operation: 'hcf', data: { hcf: [24, 36, 60] } },
  { operation: 'AI', data: { AI: "What is the capital city of Maharashtra?" } }
];

// Function to make HTTP request
function makeRequest(data) {
  return new Promise((resolve, reject) => {
    const postData = JSON.stringify(data);
    
    const options = {
      hostname: 'localhost',
      port: 3000,
      path: '/bfhl',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(postData)
      }
    };
    
    const req = http.request(options, (res) => {
      let body = '';
      res.on('data', (chunk) => {
        body += chunk;
      });
      res.on('end', () => {
        resolve({
          statusCode: res.statusCode,
          body: JSON.parse(body)
        });
      });
    });
    
    req.on('error', (err) => {
      reject(err);
    });
    
    req.write(postData);
    req.end();
  });
}

// Test health endpoint
function testHealth() {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'localhost',
      port: 3000,
      path: '/health',
      method: 'GET'
    };
    
    const req = http.request(options, (res) => {
      let body = '';
      res.on('data', (chunk) => {
        body += chunk;
      });
      res.on('end', () => {
        resolve({
          statusCode: res.statusCode,
          body: JSON.parse(body)
        });
      });
    });
    
    req.on('error', (err) => {
      reject(err);
    });
    
    req.end();
  });
}

// Run tests
async function runTests() {
  console.log('Testing BFHL API...\n');
  
  // Test health endpoint
  try {
    console.log('Testing GET /health...');
    const healthResult = await testHealth();
    console.log(`Status: ${healthResult.statusCode}`);
    console.log('Response:', JSON.stringify(healthResult.body, null, 2));
    console.log('✅ Health endpoint working\n');
  } catch (error) {
    console.error('❌ Health endpoint failed:', error.message);
  }
  
  // Test BFHL operations
  for (const test of tests) {
    try {
      console.log(`Testing POST /bfhl with ${test.operation}...`);
      const result = await makeRequest(test.data);
      console.log(`Status: ${result.statusCode}`);
      console.log('Response:', JSON.stringify(result.body, null, 2));
      console.log('✅', test.operation, 'operation working\n');
    } catch (error) {
      console.error('❌', test.operation, 'operation failed:', error.message);
    }
  }
}

runTests().catch(console.error);
