require('dotenv').config();

console.log('Environment Variables Check:');
console.log('OFFICIAL_EMAIL:', process.env.OFFICIAL_EMAIL);
console.log('GEMINI_API_KEY:', process.env.GEMINI_API_KEY ? 'Set (length: ' + process.env.GEMINI_API_KEY.length + ')' : 'Not set');
console.log('PORT:', process.env.PORT);

if (process.env.GEMINI_API_KEY) {
  console.log('API Key starts with:', process.env.GEMINI_API_KEY.substring(0, 10) + '...');
}
