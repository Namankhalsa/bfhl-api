#!/usr/bin/env node

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

console.log('🚀 BFHL API Deployment Helper\n');

// Check if required files exist
const requiredFiles = ['package.json', 'index.js', '.env.example', 'README.md'];
console.log('📋 Checking required files...');

for (const file of requiredFiles) {
  if (fs.existsSync(file)) {
    console.log(`✅ ${file}`);
  } else {
    console.log(`❌ ${file} - Missing!`);
    process.exit(1);
  }
}

// Check if .env exists
if (!fs.existsSync('.env')) {
  console.log('\n⚠️  .env file not found. Creating from .env.example...');
  fs.copyFileSync('.env.example', '.env');
  console.log('📝 Created .env file - Please update with your actual values');
}

// Check package.json scripts
const packageJson = JSON.parse(fs.readFileSync('package.json', 'utf8'));
if (!packageJson.scripts.start) {
  console.log('❌ Missing start script in package.json');
  process.exit(1);
}

console.log('\n🔧 Environment Setup:');
console.log('1. Update .env file with your Chitkara email');
console.log('2. Add your Gemini API key from https://aistudio.google.com');
console.log('3. Set OFFICIAL_EMAIL=your.email@chitkara.edu.in');
console.log('4. Set GEMINI_API_KEY=your_actual_api_key');

console.log('\n🌐 Deployment Options:');
console.log('1. Vercel: vercel --prod');
console.log('2. Railway: railway up');
console.log('3. Render: Connect GitHub repository');
console.log('4. ngrok (testing): ngrok http 3000');

console.log('\n🧪 Testing:');
console.log('Run: npm start');
console.log('Test: node test.js');

console.log('\n📦 Ready for deployment!');
console.log('Don\'t forget to:');
console.log('- Push to GitHub repository');
console.log('- Configure environment variables on deployment platform');
console.log('- Test all endpoints after deployment');
