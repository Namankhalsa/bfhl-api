# Deployment Guide

## Quick Deployment Options

### 1. Vercel (Recommended for Node.js)

1. **Install Vercel CLI**
```bash
npm i -g vercel
```

2. **Login to Vercel**
```bash
vercel login
```

3. **Deploy**
```bash
vercel --prod
```

4. **Set Environment Variables**
   - Go to your Vercel dashboard
   - Navigate to project settings
   - Add environment variables:
     - `OFFICIAL_EMAIL`: your.chitkara@chitkara.edu.in
     - `GEMINI_API_KEY`: your_gemini_api_key

### 2. Railway

1. **Login to Railway**
```bash
npm i -g @railway/cli
railway login
```

2. **Initialize and Deploy**
```bash
railway init
railway up
```

3. **Configure Environment Variables**
   - In Railway dashboard, add:
     - `OFFICIAL_EMAIL`: your.chitkara@chitkara.edu.in
     - `GEMINI_API_KEY`: your_gemini_api_key

### 3. Render

1. **Connect GitHub Repository**
   - Go to render.com
   - Connect your GitHub account
   - Select this repository

2. **Configure Service**
   - Web Service
   - Build Command: `npm install`
   - Start Command: `npm start`
   - Add environment variables in dashboard

### 4. ngrok (Temporary Testing)

1. **Install ngrok**
```bash
# Download from https://ngrok.com/download
```

2. **Run local server**
```bash
npm start
```

3. **Expose with ngrok**
```bash
ngrok http 3000
```

## Environment Variables Required

| Variable | Description | Example |
|----------|-------------|---------|
| `OFFICIAL_EMAIL` | Your Chitkara University email | `your.name@chitkara.edu.in` |
| `GEMINI_API_KEY` | Google Gemini API key | `AIzaSy...` |
| `PORT` | Server port (optional) | `3000` |

## Getting Gemini API Key

1. Visit https://aistudio.google.com
2. Sign in with Google account
3. Click "Get API Key"
4. Create API key in project
5. Copy the key

## Testing After Deployment

### Health Check
```bash
curl https://your-domain.com/health
```

### BFHL Operations
```bash
# Fibonacci
curl -X POST https://your-domain.com/bfhl \
  -H "Content-Type: application/json" \
  -d '{"fibonacci": 7}'

# Prime numbers
curl -X POST https://your-domain.com/bfhl \
  -H "Content-Type: application/json" \
  -d '{"prime": [2,4,7,9,11]}'

# LCM
curl -X POST https://your-domain.com/bfhl \
  -H "Content-Type: application/json" \
  -d '{"lcm": [12,18,24]}'

# HCF
curl -X POST https://your-domain.com/bfhl \
  -H "Content-Type: application/json" \
  -d '{"hcf": [24,36,60]}'

# AI Query
curl -X POST https://your-domain.com/bfhl \
  -H "Content-Type: application/json" \
  -d '{"AI": "What is the capital city of Maharashtra?"}'
```

## GitHub Repository Setup

1. **Initialize Git**
```bash
git init
git add .
git commit -m "Initial BFHL API implementation"
```

2. **Create GitHub Repository**
   - Go to github.com
   - Create new public repository
   - Copy repository URL

3. **Push to GitHub**
```bash
git remote add origin https://github.com/yourusername/bfhl-api.git
git branch -M main
git push -u origin main
```

## Troubleshooting

### Common Issues

1. **AI Service Unavailable (503)**
   - Check GEMINI_API_KEY is set correctly
   - Verify API key is valid and has credits

2. **Server Crashes**
   - Check logs for specific errors
   - Ensure all dependencies are installed

3. **CORS Issues**
   - API has CORS enabled by default
   - For specific domains, modify CORS settings

4. **Rate Limiting**
   - Default: 100 requests per 15 minutes per IP
   - Adjust in index.js if needed

### Monitoring

- Check platform-specific logs (Vercel, Railway, Render)
- Monitor API usage and response times
- Set up alerts for high error rates

## Production Considerations

- Set up proper logging
- Monitor API usage and costs
- Implement additional security if needed
- Consider CDN for static assets
- Set up backup and recovery procedures
