require('dotenv').config();
const { GoogleGenerativeAI } = require('@google/generative-ai');

async function listModels() {
  try {
    const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || "AIzaSyBvWraXpJwzWqcLmpe7UUXtl7KHW3vZaxg");
    console.log('🔍 Listing available models...');
    
    // Try different model names that might work
    const models = [
      "gemini-1.5-pro",
      "gemini-1.5-flash",
      "gemini-pro",
      "gemini-pro-vision",
      "text-bison-001",
      "chat-bison-001"
    ];
    
    for (const modelName of models) {
      try {
        console.log(`🧪 Testing model: ${modelName}`);
        const model = genAI.getGenerativeModel({ model: modelName });
        await model.generateContent("Hello");
        console.log(`✅ ${modelName} - WORKS`);
      } catch (error) {
        console.log(`❌ ${modelName} - ${error.message}`);
      }
    }
    
  } catch (error) {
    console.error('❌ Error:', error.message);
  }
}

listModels();
