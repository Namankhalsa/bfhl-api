require('dotenv').config();
const { GoogleGenerativeAI } = require('@google/generative-ai');

console.log('Testing AI API...');
console.log('API Key:', process.env.GEMINI_API_KEY ? 'Set' : 'Not set');

if (!process.env.GEMINI_API_KEY) {
  console.error('❌ API Key not found in environment variables');
  process.exit(1);
}

try {
  const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
  console.log('✅ Gemini AI initialized');
  
  const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
  console.log('✅ Model loaded');
  
  const testQuestion = "What is the capital of India?";
  console.log('🤖 Asking:', testQuestion);
  
  model.generateContent(testQuestion).then(result => {
    console.log('✅ Response received');
    return result.response;
  }).then(response => {
    return response.text();
  }).then(text => {
    console.log('📝 Answer:', text.trim());
  }).catch(error => {
    console.error('❌ Error:', error.message);
  });
  
} catch (error) {
  console.error('❌ Initialization error:', error.message);
}
